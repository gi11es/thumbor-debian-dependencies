# Authors

* Antoine Vacavant, ISIT lab, antoine.vacavant@iut.u-clermont1.fr, http://isit.u-clermont1.fr/~anvacava
* Christopher Godfrey
* Jeff Terrace, jterrace@gmail.com
* Wieland Morgenstern
* Gabriele Lami, koteth@gmail.com 
* Martin McGreal, CTY, martin@cty.io, http://cty.io
* Christoph Koerner, office@chaosmail.at
