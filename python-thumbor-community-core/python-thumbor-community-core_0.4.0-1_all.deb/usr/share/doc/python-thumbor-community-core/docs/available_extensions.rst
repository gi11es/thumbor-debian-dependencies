Available Thumbor Community Extensions
======================================

* `URL Shortener`_

.. _`URL Shortener`: https://github.com/thumbor-community/shortener
