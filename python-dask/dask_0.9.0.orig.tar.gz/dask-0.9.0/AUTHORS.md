[Arve](http://arve0.github.io/)

[Benjamin Regan-Kelley](https://github.com/minrk)

[Blake Griffith](http://github.com/cowlicks)

[Casey Clements](https://github.com/caseyclements)

[Christine Doig](https://github.com/chdoig)

[Clark Fitzgerald](https://github.com/clarkfitzg)

[Erik Welch](http://github.com/eriknw/)

[Erkka Rinne](https://github.com/ererkka)

[Eyad Sibai](https://github.com/eyadsibai)

[Gabriele Lanaro](http://gabrielelanaro.github.io/)

[Jim Crist](http://jcrist.github.io/)

[John Kirkham](https://github.com/jakirkham)

[Jon Renner](https://github.com/jrenner/)

[Joshua Corbin](https://github.com/jcorbin)

[Kristopher Overholt](https://github.com/koverholt)

[Kurt Smith](https://github.com/kwmsmith)

[Mariano Tepper](http://www.marianotepper.com.ar/)

[Matthew Rocklin](http://matthewrocklin.com/)

[Nicholaus Jackson](https://github.com/NoonienSoong/)

[Olivier Grisel](http://ogrisel.com/)

[Pedro Duarte](https://github.com/PedroMDuarte)

[Peter Steinberg](https://github.com/PeterDSteinberg/)

[Peter Quackenbush](https://github.com/thequackdaddy/)

[Phil Elson](https://github.com/pelson)

[Ruggero Turra](https://github.com/wiso)

[Scott Sanderson](https://github.com/ssanderson)

[Stephan Hoyer](http://stephanhoyer.com)

[Sigurd Spieckermann](https://github.com/sisp)

[sinhrks](https://github.com/sinhrks)

[Stuart Owen](http://stuartowen.com/)

[Thomas Smith](https://github.com/tgs)

[Tom Augspurger](https://github.com/TomAugspurger)

[Travis Oliphant](https://github.com/teoliphant)

[Valentin Haenel](http://haenel.co/)

[Vikhyat Korrapati](http://vikhyat.net/)

[Wesley Emeneker](http://github.com/nevermindewe/)

[Will Warner](https://github.com/electronwill/)

[Daniel Davis](https://github.com/wabu)
