from __future__ import absolute_import

from cloudpickle.cloudpickle import *

__version__ = '0.2.1'
