Contributing
============

If you wish to contribute to Thumbor-Community, please abide by the `Code of conduct`_.

.. _`Code of conduct`: https://github.com/thumbor-community/code-of-conduct
