version = '0.18.0+git114-g6c692ae'
short_version = '0.18.0'
