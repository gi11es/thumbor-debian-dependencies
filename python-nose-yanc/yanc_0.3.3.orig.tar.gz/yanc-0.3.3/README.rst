YANC
----

YANC is color output plugin for nose that plays nicely with others.

To enable the plugin pass `--with-yanc` to `nosetests`.

.. image:: http://img.shields.io/travis/0compute/yanc/master.png
    :target: http://travis-ci.org/0compute/yanc
    :alt: Build

.. image:: http://img.shields.io/coveralls/0compute/yanc/master.png
    :target: https://coveralls.io/r/0compute/yanc
    :alt: Coverage

.. image:: https://landscape.io/github/0compute/yanc/master/landscape.png
    :target: https://landscape.io/github/0compute/yanc/master
    :alt: Code Health

.. image:: http://img.shields.io/pypi/v/yanc.png
    :target: https://pypi.python.org/pypi/yanc/
    :alt: Latest Version

.. image:: https://pypip.in/license/yanc/badge.png
    :target: https://github.com/0compute/yanc/blob/master/LICENSE
    :alt: License
