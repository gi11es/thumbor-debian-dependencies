##1.4.2 (2013-06-21)
* __str__ returns correctly with dsn
* worker_pids returns correct set of workers
* workers are re-registered on every job
* add exception metadata for after_perform method
* logger no longer overrides root logger
* support for redis db in dsn

##1.4.1 (2012-07-30)
* fix for non existent system signal for linux
* cleanup of setup.py and requirements

##1.4 (2012-06-?)
* added hooks for before and after perform methods
* fixed logging
*fixed problems with password authentication

##1.3 (2012-06-01)
* remove resweb from pyres
* resweb is now available at http://github.com/Pyres/resweb or on pypi

##1.2
* release with changes from pull requests

##1.1 (2011-06-16)
* api change based on redis-py
* setproctitle requirements fix
* change exception logging in worker

##1.0.1 (2011-04-12)
* fixed bug with tempaltes and media in resweb
* call to redis-py disconnect was failing, switched to connection.disconnect
* interval cast to int for pyres_worker script command

## 0.9.1 (2010-10-15)
* fixing issues #45, #46.
	* #45 - resweb not working in chrome
	* #46 - delayed_queue_schedule_size() returns incorrect value
* updated version requirement for redis-py
* added Failure docs from Alex._

## 0.9 (2010-08-05)
* added better logging to the project

## 0.8 (2010-04-24)
* added the pyres_manager and the horde module. This allows a more prefork like model for processing jobs.
* setproctitle usage. Allows better process titles when viewing via ps
* ability to delete and requeue failed items

## 0.7.5.1 (2010-03-18)
* fixed the pyres_scheduler script
* changed download link to remove v from version number

## 0.7.5 (2010-03-18)
* added feature to retry jobs based on a class attribute

## 0.7.1 (2010-03-16)
* bug fix for pruning workers.

## 0.7.0 (2010-03-05)
* delayed tasks
* resweb pagination
* switch stored timestamps to a unix timestamp
* updated documentation
* upgraded to redis-py 1.34.1
* switched from print statements to the logging module
* import errors on jobs are now reported in the failed queue
* prune dead workers
* small bugfixes in the resweb package
* improved failure formatting
* datetime json parser

## 0.5.0 (2010-0114)

* added new documentation to the project
* update setup.py
* preparing for semantic versioning

## 0.4.1 (2010-01-06)

* fixed issue with new failure package in distutils sdist
* changed setup.py to remove camel case, because it's ugly

## 0.4.0 (2010-01-06)

* added the basics of failure backend support

## 0.3.1 (2009-12-16)

* minor bug fix in worker.py
* merged in some setup.py niceties from dsc fork
* merged in better README info from dsc fork

## 0.3.0 (2009-12-10)

* updated setup.py
* refactored package for better testing
* resque namespacing by fakechris
* smarter import from string by fakechris

## 0.2.0 (2009-12-09)

* Better web interface via resweb
* Updated the api to be more inline with resque
* More tests.

## 0.1.0 (2009-12-01)

* First release.
