User mailing list
=================

On Should-DSL user list you can ask questions on its daily use:

http://groups.google.com.br/group/should-dsl


---------------------------


Development mailing list
========================

There is a mailing list dedicated to Should-DSL's development, where code ideas flow:

http://groups.google.com.br/group/should-dsl-dev


---------------------------


Keep in touch!
==============

We appreciate comments and ideas, send yours!

