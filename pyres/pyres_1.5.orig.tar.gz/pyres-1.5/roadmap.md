pyres todo and roadmap

1.3
===
* resweb moved into own package

2.0
===
* move from duck typed class to a decorated function for jobs
* add better hooks, like retools

2.1
===
* add namespace support
* cleanup workers/extensions
