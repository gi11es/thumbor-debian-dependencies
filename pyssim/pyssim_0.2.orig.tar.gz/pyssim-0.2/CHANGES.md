# Changelog

## 0.2

- Library now works on Python 3.2.
- Automated testing using Travis CI.
- Library is now lint clean.
- Automatically resize images.
- Internal refactoring using objects instead of functions.
- Minor performance improvements.

## 0.1

- Original Release.
