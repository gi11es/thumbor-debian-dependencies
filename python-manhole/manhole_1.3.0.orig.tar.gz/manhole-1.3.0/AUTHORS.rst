
Authors
=======

* Ionel Cristian Mărieș - http://blog.ionelmc.ro
* Saulius Menkevičius - https://github.com/razzmatazz
* Nir Soffer - http://nirs.freeshell.org
