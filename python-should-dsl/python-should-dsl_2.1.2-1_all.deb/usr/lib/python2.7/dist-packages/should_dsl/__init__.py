from should_dsl.dsl import (should,
                         should_not,
                         matcher,
                         add_predicate_regex,
                         matcher_configuration,
                         aliases,
                         ShouldNotSatisfied)
from should_dsl import matchers

