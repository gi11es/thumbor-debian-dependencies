#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''Allows the use of `python -m pyvows`.'''

import sys

from pyvows.cli import main

#-------------------------------------------------------------------------------------------------

if __name__ == '__main__':
    sys.exit(main())
