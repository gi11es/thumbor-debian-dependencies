def focus(thing):
    """Set the nose_focus attribute on something"""
    thing.nose_focus = True
    return thing

def focus_all(thing):
    """Set the nose_focus_all attribute on something"""
    thing.nose_focus_all = True
    return thing

def focus_ignore(thing):
    """Set the nose_focus_ignore attribute on something"""
    thing.nose_focus_ignore = True
    return thing

