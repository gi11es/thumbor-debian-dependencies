## Authors
* Matt George
* Craig Hawco
* Michael Russo
* Chris Song
* Whit Morriss
* Joe Shaw
* Yashwanth Nelapati
* Cezar Sa Espinola
* Alex Ezell
* Christy O'Reilly
* Kevin McConnell
* Bernardo Heynemann
* David Schoonover
* Rob Hudson
* Salimane Adjao Moustapha
* John Hobbs
* James M. Henderson
* Iraê Carvalho
* Fabien Reboia
* Peter Teichman


Inspired by Resque, by Chris Wanstrath
