VERSION = (0, 1, 7)
__version__ = '.'.join(map(str, VERSION))
