#: E901
}
#: E901
= [x
#: E901 E101 W191
while True:
    try:
	    pass
	except:
		print 'Whoops'
#: E122 E225 E251 E251 E701

# Do not crash if code is invalid
if msg:
    errmsg = msg % progress.get(cr_dbname))

def lasting(self, duration=300):
    progress = self._progress.setdefault('foo', {}
#: Okay

# Issue #119
# Do not crash with Python2 if the line endswith '\r\r\n'
EMPTY_SET = set()
SET_TYPE = type(EMPTY_SET)
toto = 0 + 0
#:
