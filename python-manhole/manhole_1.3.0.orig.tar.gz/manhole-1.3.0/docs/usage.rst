=====
Usage
=====

To use Manhole in a project::

	import manhole
