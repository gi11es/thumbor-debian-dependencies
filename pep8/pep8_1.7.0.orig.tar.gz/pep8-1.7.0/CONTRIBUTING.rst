Contributing to ``pep8``
========================

Please see the `developer notes <https://pep8.readthedocs.org/en/latest/developer.html>`_
