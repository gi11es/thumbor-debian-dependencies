from .result import Storage

__all__ = ['Storage']
